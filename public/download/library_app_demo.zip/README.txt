Replace this file with your real app ZIP/APK.
You can also set VITE_DOWNLOAD_URL to point to GitHub Releases.
